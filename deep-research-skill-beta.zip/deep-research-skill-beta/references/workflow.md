# Deep Research Workflow

## Phase 0: 任务理解与研究类型识别

必须先判断：

- `task_type`：公司经营决策、政府/国企汇报、技术路线、投资/公司分析、通用知识研究。
- `mode`：balanced、cost_saving、high_quality、long_context、draft_fast。
- `audience`：领导、内部团队、投资决策、技术团队、政府部门、个人学习。
- `depth`：领导速览版、标准版、深度版。
- 是否优先中国市场、中国政策、中国公司案例。
- 是否启用 long_context_agent、scenario_agent、reviewer_agent。
- 技术路线研究类必须启用 source_agent。

如果用户没有明确，但可从上下文判断，直接做合理假设，并在报告中标注“本报告采用的默认假设”。

## Phase 1: 研究问题拆解

建立 4 类问题：

- 主问题：用户真正要解决的决策问题。
- 子问题：定义、现状、价值、路线、风险、落地。
- 验证问题：哪些事实、数据、政策、案例需要来源支持。
- 反证问题：哪些失败案例、替代路径、合规风险、成本低估需要检查。

输出问题树时同时列出：

- `key_questions`
- `data_needed`
- `risk_focus`
- `required_subagents`
- `source_required_items`
- `assumption_items`

## Phase 2: 资料搜索与来源分级

### Phase 1.5 强制前置检查

进入 Phase 2 前必须先完成以下检查清单（不得跳过）：

```
[ ] 已读 references/search-tools.md（包含 Bocha / Exa / Brave API key 配置、代理配置、搜索方案矩阵）
[ ] 已确认至少一个搜索 key 可用：BOCHA_API_KEY / EXA_API_KEY / BRAVE_API_KEY
[ ] 已准备搜索词清单（经过去重和合并）
[ ] 已声明本次研究预算（按任务类型查 search-tools.md 预算表）
[ ] 已初始化搜索计数和缓存
[ ] 已确认可用的知识库来源：Lark Wiki / NotebookLM / Obsidian Vault
[ ] 已读 references/knowledge-retrieval.md（知识库适配器协议）
```

检查清单未完成前，不得进入 Phase 2。

### 搜索执行协议（按语言路由，不得跳过外部搜索）

优先使用 `scripts/search.sh` 统一入口。它会按语言和已配置 key 自动路由：

- 中文：Bocha → Brave → Exa。
- 英文：Exa → Brave → Bocha。
- `--parallel`：中文并发 Bocha + Brave，英文并发 Exa + Brave。

每步完成后评估结果再决定是否进入下一步：

**第 1 步：Scheme A — 统一搜索脚本（必须执行）**

```
scripts/search.sh "查询关键词" --parallel
```
- 详情见 [references/search-tools.md](references/search-tools.md)
- 禁止跳过此步直接走 Bing 或标记搜索失败

**第 2 步：Scheme B — Bing 通用搜索（API 搜索结果不足时）**

```
webfetch(format="markdown", url="https://cn.bing.com/search?q=KEYWORD")
```

**第 3 步：Scheme C — 直接抓取已知权威来源**

从 API/Bing 结果中识别权威 URL，用 webfetch 抓取完整页面。

**第 4 步：Scheme D — 英文搜索发现中文来源**

用英文关键词搜 Exa 或 Brave API，从英文文章引用中发现中文权威来源。

**第 5 步：全部失败 → 记录 source_failure_log**

确认所有搜索方案均失败后，才能标记"搜索失败"。

### 强制外部搜索规则

- 默认必须发起外部联网搜索，不可跳过。仅当用户**明确**指示"不需要联网搜索""离线分析""不用搜索""仅本地资料"时，方可跳过。
- 用户说"快速初稿""先给框架""简单整理"等不构成跳过搜索的理由——除非明确说"不用联网"。
- 搜索失败的，必须记录 `source_failure_log`，按降级规则标注为"离线初稿"或"待联网核验版"，不得标为"正式高质量报告"。
- `high_quality` 模式下搜索失败 → 审计等级最高 `CONDITIONAL_PASS`。
- `cost_saving` / `draft_fast` 模式下，仍需尝试外部搜索；搜索失败时不强制降级但必须记录。
- 搜索执行后必须报告"用了哪些 Scheme + 成功/失败 + 下一步"。

优先使用 S/A/B 来源。对每条关键数据记录：

- 标题。
- URL 或文件名。
- 来源等级。
- 发布日期或文件日期。
- 获取日期。
- 统计口径。
- 可引用事实。
- 可靠性备注。

如果公开资料不足，写明“缺少可靠公开数据，需进一步核验”，并进入数据缺口清单。

如果 web 搜索、外部检索、资料抓取或来源验证失败，必须记录 `source_failure_log`，并将 high_quality 报告降级为“离线初稿”或“待联网核验版”。

### 知识库检索（与网页搜索并行执行）

除了网页搜索外，source_agent 还须执行知识库检索以获取内部资料：

1. 调用 `scripts/knowledge-retrieval.sh "关键词"`（自动检测可用来源）
2. 对返回结果按 `source-policy.yaml` 中的来源类型进行分类和定级
3. 知识库检索失败不影响网页搜索，反之亦然
4. 各自记录 `source_failure_log`

可用知识库来源：
- **飞书知识库**（lark_wiki）：内部项目文档、技术文档、管理制度
- **NotebookLM**（notebooklm）：AI 分析视角和来源材料
- **Obsidian Vault**（obsidian/local_vault/local_wiki）：本地笔记、技术 Wiki

来源等级映射：
- 飞书正式文档 → A 级
- 飞书笔记/草稿 → B 级
- Obsidian 技术 Wiki → B/C 级（local_wiki）
- Obsidian 工作笔记 → B/C 级（local_vault）
- NotebookLM AI 分析 → C 级（model_reasoning）
- NotebookLM 来源材料 → 按原类型定级

## Phase 3: 事实核验与反证扫描

每个重大结论必须检查：

1. 有没有相反案例。
2. 有没有失败案例。
3. 有没有监管或合规风险。
4. 有没有市场需求不足的可能。
5. 有没有成本被低估。
6. 有没有商业模式不成立的可能。
7. 有没有技术落地难度被低估。
8. 有没有数据来源偏旧或口径不一致。

报告必须有“风险、反证与不确定性”部分。

## Phase 4: 分析建模

按任务类型选择模型：

- 公司经营决策：价值判断、投入产出、资源匹配、风险收益、试点验证。
- 政府/国企汇报：问题-目标-路径-机制、政策对齐、多部门协同、试点示范推广。
- 技术路线：技术成熟度 TRL、成本/性能/可维护性、自研/采购/合作、工程复杂度、替代路线。
- 投资分析：行业空间、竞争格局、财务质量、估值对比、催化因素、风险因素、情景估值。
- 通用研究：定义、历史演进、主流路线、争议点、案例、趋势。

## Phase 5: 情景化测算

涉及市场空间、收入、利润、用户数、回收期、储值金额、估值、成本节约、效率提升时，不得只给单点预测。

必须输出：

- 保守情景。
- 中性情景。
- 积极情景。
- 输入假设。
- 敏感因素。
- 无法计算项。
- 需补充真实数据。

缺数据时写：“以下为情景假设，不作为最终决策依据，需结合公司真实经营数据复核。”

## Phase 6: 报告写作

写作要求：

- 结论先行。
- 正文优先，表格辅助；每个关键章节先写 2-4 段分析，再用表格或列表补充。
- 表格之后必须写一段“表格解读/决策含义”，说明这些数据或对比对结论有什么影响。
- 区分事实、推理、假设。
- 不新增没有来源或没有标注的数据。
- 公司决策必须回答“是否建议推进”和“推进到什么程度”。
- 政府/国企材料语言稳健、正式、克制。
- 投资分析必须提示不构成投资建议。
- 模型说明必须基于真实可检测上下文；无法检测时写“模型使用未能自动验证”。
- high_quality 如搜索失败、来源不足或模型无法验证，报告开头必须标注离线初稿/待联网核验版。

## Phase 7: 质量审计与自动修订

使用 reviewer_agent 对照 `quality-review.md` 和 `execution-consistency.md` 审计。审计等级为 `PASS`、`CONDITIONAL_PASS`、`FAIL`。若为 `CONDITIONAL_PASS` 或 `FAIL`，自动修订一次并保留人工核验项。

最终交付必须说明：

- 本次模式。
- 启用 Subagent。
- 模型分工。
- 真实模型检测状态。
- 模型路由执行状态。
- 搜索状态。
- 审计等级。
- 报告可用性。
- 是否触发模型升级。
- 是否触发 fallback。
- 来源审计状态。
- source_failure_log。
- 数据缺口。
- 人工复核事项。
