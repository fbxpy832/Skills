# Host Adapter Contract

This document defines the integration contract between the Deep Research Skill protocol layer and any host environment (Codex, OpenCode, Claude Code, CloudCode, GUI, TU/terminal runners, or external orchestrators).

---

## 1. Configuration Layer

Every host adapter MUST read the shared configuration from `~/.config/deep-research-skill/`:

| File | Purpose | Required |
|------|---------|:--------:|
| `config.env` | Provider credentials, agent model routes, output directory, search API keys | Yes |
| `providers.env` | Human-readable provider registry | No |

The config path can be overridden via:

```bash
export DEEP_RESEARCH_SKILL_CONFIG_DIR="/path/to/alt-config"
export DEEP_RESEARCH_CONFIG_ENV="/path/to/alt-config/config.env"
```

### 1.1 Model Route Resolution

Every host MUST call `scripts/model-router.sh MODE AGENT` to resolve the requested model route. The output is a `provider/model` string.

```bash
# Example
model="$(scripts/model-router.sh high_quality planner_agent)"
# Returns: opencode-go/deepseek-v4-pro
```

Hosts MUST NOT hardcode model names. The router is the single source of truth.

### 1.2 Credential Handling

- Credentials are stored ONLY in `config.env` (permissions `0600`).
- Hosts MUST export the relevant API key environment variable BEFORE invoking any model call.
- Hosts MUST NOT log, print, or store API keys in artifacts.
- Use the `provider_var_name()` pattern from the existing runners for safe env-var mapping.

---

## 2. Agent Invocation

### 2.1 Agent List

The standard agent pipeline consists of 7 agents:

| Agent | Index | Phase | Role |
|-------|-------|-------|------|
| `planner_agent` | 01 | Planning | Research plan, task classification, source planning |
| `source_agent` | 02 | Evidence Collection | Web search, source collection, source grading |
| `long_context_agent` | 03 | Evidence Collection | Long document reading, multi-file summarization |
| `analyst_agent` | 04 | Analysis | Fact verification, cross-reference, gap analysis |
| `scenario_agent` | 05 | Scenario Modeling | Financial modeling, market sizing, projections |
| `writer_agent` | 06 | Report Writing | Final report composition, source attribution |
| `reviewer_agent` | 07 | Quality Audit | Output review, source audit, PASS/CONDITIONAL_PASS/FAIL |

### 2.2 Stage Dependencies

```
Stage 1: planner_agent
Stage 2: source_agent + long_context_agent (parallel)
Stage 3: analyst_agent + scenario_agent (parallel)
Stage 4: writer_agent
Stage 5: reviewer_agent
```

Hosts MAY run stages in parallel or sequentially, but MUST respect the dependency order.

### 2.3 Agent Input/Output Contract

Each agent invocation receives:
- **Prompt file**: `prompts/XX-agent.md` — contains task description, mode, requested model, dependency outputs
- **Agent-specific instruction**: references from `SKILL.md` and `references/subagents.md`

Each agent produces:
- **Output file**: `outputs/XX-agent.md` — agent's structured Markdown output
- **Log file**: `logs/XX-agent.log` — timing and model metadata

### 2.4 Model Detection Protocol

Hosts MUST distinguish between request and actual:

| Field | Meaning | Source |
|-------|---------|--------|
| `requested_model` | What the router recommended | `model-router.sh` output |
| `actual_model_detection_status` | Can the host verify the model? | Host logs/API response |
| `model_route_execution_status` | Did the route succeed? | Host state |

Allowed values for `actual_model_detection_status`:
- `verified` — Host can confirm the actual model from API response/logs
- `partially_verified` — Some but not all evidence available
- `not_verified` — Cannot determine actual model (default for dry-runs)

Allowed values for `model_route_execution_status`:
- `real_switch` — Model was successfully switched/used as routed
- `instruction_level_recommendation` — Route was suggested but not enforced
- `unable_to_verify` — Cannot confirm (default for dry-runs and unverifiable hosts)

**CRITICAL RULE**: Never claim a model was "used" unless host logs, API responses, or UI state verify it. If unverified, write "模型使用未能自动验证".

---

## 3. Progress Events (`events.ndjson`)

Every host adapter MUST write a structured event stream to `events.ndjson` in the output directory. Each line is a compact JSON object (no pretty-printing).

### 3.1 Event Schema

```json
{"timestamp":"2026-05-19T14:30:00+08:00","run_id":"20260519-143000","phase":"stage_1_planning","agent":"planner_agent","status":"started","requested_model":"opencode-go/deepseek-v4-pro","detected_model_status":"not_verified","message":"Starting planner_agent","error":""}
```

### 3.2 Required Fields

| Field | Type | Required | Description |
|-------|------|:--------:|-------------|
| `timestamp` | string (ISO 8601) | Yes | Event time: `YYYY-MM-DDTHH:MM:SS+TZ` |
| `run_id` | string | Yes | Run identifier (matches output directory name) |
| `phase` | string | Yes | Research phase or stage name |
| `agent` | string | No | Agent name (empty for run-level events) |
| `status` | string | Yes | Event status |
| `requested_model` | string | No | Model route recommendation |
| `detected_model_status` | string | No | `verified` / `not_verified` |
| `message` | string | Yes | Human-readable description |
| `error` | string | No | Error details (empty on success) |

### 3.3 Standard Event Statuses

| Status | Meaning |
|--------|---------|
| `started` | Entity started execution |
| `completed` | Entity finished successfully |
| `failed` | Entity terminated with error |
| `skipped` | Entity was disabled/bypassed |

### 3.4 Standard Event Types

| Event | `phase` | `agent` | When |
|-------|---------|---------|------|
| `run_started` | `run` | `""` | Before any agent runs |
| `agent_started` | `stage_N_name` | agent name | Before each agent invocation |
| `agent_completed` | `stage_N_name` | agent name | After agent returns success |
| `agent_failed` | `stage_N_name` | agent name | After agent returns error |
| `stage_started` | `stage_N_name` | `""` | Before each parallel stage |
| `stage_completed` | `stage_N_name` | `""` | After all agents in stage finish |
| `run_completed` | `run` | `""` | After all stages complete |

### 3.5 Security Constraint

Events MUST NOT contain API keys, credentials, tokens, or secrets. The `requested_model` field may contain provider prefixes (e.g., `opencode-go/deepseek-v4-pro`) but never raw API keys.

---

## 4. Required Artifacts

Every host adapter run MUST produce these files in the output directory:

| Artifact | Format | Required | Description |
|----------|--------|:--------:|-------------|
| `run-summary.md` | Markdown | Yes | Task, mode, agents, model mapping, output file listing |
| `execution-context.md` | Markdown | Yes | Runtime config, provider registry, model detection status |
| `source_failure_log.md` | Markdown + YAML | Conditional | Source/search/fetch failure records; created even if empty |
| `events.ndjson` | NDJSON (one JSON per line) | Yes | Structured event stream |
| `prompts/` | Directory | Yes | Per-agent prompt files (`XX-agent.md`) |
| `outputs/` | Directory | Yes | Per-agent output files (`XX-agent.md`) |
| `logs/` | Directory | Yes | Per-agent log files (`XX-agent.log`) |

---

## 5. Error Codes

| Code | Name | Description |
|:----:|------|-------------|
| 0 | `SUCCESS` | Run completed without errors |
| 1 | `ERR_CONFIG` | Config file not found or unreadable |
| 2 | `ERR_TASK` | Task file missing or empty |
| 3 | `ERR_ROUTER` | Model router not found or not executable |
| 4 | `ERR_HOST` | Host binary not found (e.g., opencode CLI) |
| 5 | `ERR_AGENT` | Agent execution failed |
| 6 | `ERR_STAGE` | Stage execution failed |
| 7 | `ERR_OUTPUT` | Output directory not writable |
| 8 | `ERR_SEARCH` | Search backend unavailable |
| 9 | `ERR_DRY_RUN_BLOCK` | Feature requires live execution |

---

## 6. Fallback Behavior

### 6.1 Host Unavailable

If the host binary (e.g., `opencode`, `codex`) is not found:
1. Report `ERR_HOST` (exit code 4).
2. The generic runner can proceed in dry-run mode to generate prompts/artifacts without invoking a host.

### 6.2 Model Router Fallback

If `model-router.sh` returns empty or fails:
1. Fall back to `opencode-go/deepseek-v4-pro` as default.
2. Log the fallback in `execution-context.md`.
3. Set `detected_model_status=not_verified`.

### 6.3 Agent Failure

If any agent fails:
1. Record `agent_failed` event with error details.
2. Continue with remaining agents if possible (best-effort).
3. Mark `run_completed` with partial success note.
4. Set `audit_grade_cap` to at most `CONDITIONAL_PASS`.

### 6.4 Search Failure

If search tools fail:
1. Record in `source_failure_log.md`.
2. Emit `agent_failed` for `source_agent`.
3. Downgrade report usability per `references/source-failure-log.md`.
4. Continue with remaining agents using local-only data.

---

## 7. Host-Specific Notes

### OpenCode
- Binary: `opencode`
- Detection: `command -v opencode` or `OPENCODE_BIN` env var
- Model passing: `opencode run --model <model> < prompt.md`
- Model detection: OpenCode UI/state can verify actual model (but runner should not assume)

### Codex
- Binary: `codex` (Codex CLI)
- No direct model flag; Codex manages model selection internally
- Model routing is advisory only
- Always set `actual_model_detection_status=not_verified` unless Codex provides detection

### Claude Code
- Binary: `claude`
- Model selection via provider configuration, not CLI flag
- Same advisory routing model as Codex

### CloudCode / GUI / TU/Terminal
- These hosts manage agent invocation through their own runtime
- The generic runner (`scripts/generic-research-runner.sh`) is designed for these hosts
- They consume prompt files and produce outputs using their own execution engines

### External Orchestrators
- Any orchestrator can read the config, call the router, generate prompts, and invoke agents
- Must adhere to this contract for artifact production
- Should use `generic-research-runner.sh` as a reference implementation

---

## 8. Compliance Checklist

Before claiming host adapter compliance, verify:

- [ ] Reads config from `~/.config/deep-research-skill/config.env`
- [ ] Calls `scripts/model-router.sh MODE AGENT` for each agent
- [ ] Distinguishes `requested_model` from actual model detection
- [ ] Writes `run-summary.md` with complete model mapping
- [ ] Writes `execution-context.md` with detection status
- [ ] Writes `source_failure_log.md` (even if empty)
- [ ] Writes `events.ndjson` with all 7 event types
- [ ] Never logs API keys or secrets
- [ ] Respects stage dependency order (planner, source+long_context, analyst+scenario, writer, reviewer)
- [ ] Follows agent input/output contract from `references/subagents.md`
- [ ] Applies quality downgrade rules per `references/source-failure-log.md`
- [ ] Reports exit codes as defined in Section 5
